# Trace — Product Spec & Design History

> Working document for the Trace product. Captures everything we've explored so far, what's locked in, what's parked, and what's been dropped. Designed to give context to Claude Code (or any other engineer) who picks this up next.

---

## 1. Product summary

**Trace** is a web tool that turns a static SVG logo into a stroke-by-stroke animated video. The user uploads an SVG, tweaks the timing (draw, fill, stagger, hold), and exports to MOV (with alpha), GIF, Lottie JSON, CSS keyframes, or a Python/MoviePy script.

**Audience:** designers, marketers, devs who need a quick branded reveal animation without opening After Effects.

**Core flow:** drop SVG → preview animates → adjust → export.

---

## 2. Brand & visual system (locked)

### Logo — direction A2 ("inline arc")
Wordmark `trace` with the letter **a** replaced by a small gradient arc + dot. The arc is a quadratic Bézier with rounded caps, gradient stroke, accompanied by a solid-color dot at the end anchor.

- **Wordmark family:** Geist Regular 500
- **Wordmark color:** `#FFFFFF` on dark, `#0A0A14` on light
- **Gradient:** linear, 45°, `#A78BFA` → `#EC4899`
- **Dot color:** `#EC4899` (solid)
- **Stroke weight:** 6 pt at 64 pt cap height (≈9.4%)
- **Stroke profile:** round cap, round join, center alignment

Full Illustrator handoff including geometry, swatches, raw SVG path data, clear space, and minimum sizes lives in `Trace Logo Handoff.html`.

### Editor visual direction (locked)
**"Light hybrid #1"** — gradient hero band over a clean white workspace.

- Hero band: `linear-gradient(135deg, #1e1b4b 0%, #4c1d95 35%, #831843 100%)` with violet + pink radial halos blurred 40px
- Workspace: `#fff` with a subtle 32×32 px grid (`rgba(0,0,0,0.025)` 1px lines)
- Sidebar: `#fff`, 320px, `1px solid #ededed` divider
- Preview: `#0d0b18` rounded card (radius 18) with conic gradient halo behind (blur 70px, opacity 0.3)
- Sliders: gradient fill (violet → pink), 12 px white thumb with soft shadow + halo
- All-caps mono labels (Geist Mono, 1.4 letter-spacing)
- Italic Instrument Serif used for hero/marketing typography (empty state, modals)

### Type
- **UI:** Geist (300/400/500/600)
- **Mono:** Geist Mono (400/500)
- **Display / editorial:** Instrument Serif (italic and roman)

### Color tokens
| Token | Value | Usage |
|---|---|---|
| `--violet-500` | `#7c3aed` | primary action, gradient anchor |
| `--violet-400` | `#a78bfa` | gradient start, accents |
| `--pink-500`   | `#ec4899` | gradient end, dot, highlights |
| `--ink`        | `#0a0a14` | primary text |
| `--ink-700`    | `#3f3f46` | secondary text |
| `--ink-500`    | `#71717a` | tertiary text, captions |
| `--ink-300`    | `#a1a1aa` | hints, mono labels |
| `--surface`    | `#ffffff` | cards, modals |
| `--surface-2`  | `#fafafa` | panels |
| `--surface-3`  | `#f4f4f5` | hover, segmented bg |
| `--border`     | `#ededed` | dividers |
| `--canvas-dark`| `#0d0b18` | preview surface |
| `--success`    | `#10b981` | live-preview indicator |

---

## 3. Features — locked-in (8)

These are the features in the current working demo (`Trace Demo.html`).

### F5 · Empty state with built-in samples 🟢 LOCKED
Full-bleed hero on first load. Italic serif headline `animate logos like they breathe`. Dropzone is the workspace, with 4 built-in sample SVGs below for immediate try-without-upload.
- Samples: Geometric, Monogram, Checkmark, Star burst
- Sample picker buttons show a 22×22 px preview thumbnail of each SVG

### F6 · Smart defaults toggle 🟢 LOCKED
Toggle in sidebar (default ON). When ON, on file load, Trace inspects path count and length and tunes draw duration, stagger, fill, and hold. When OFF, the same default values are used for every file. User can override sliders either way.
- Tuning rules (heuristic):
  - 1 path → draw 1.8s, stagger 0.0s
  - 2 paths → draw 2.2s, stagger 0.18s
  - 3+ paths → draw 2.8s, stagger 0.18s
  - fill always starts 1.0s, hold 0.6s

### F1 · Path reorder 🟢 LOCKED
Sidebar lists each detected path as a draggable row. Top of list = animates first.
- Drag handle (left) — full row is draggable
- Color swatch (clickable) — opens inline color picker (F8)
- Path name — auto-detected from SVG `id`/`title` or generic ("Path 1", "Path 2")
- Order index (right, mono) — `1`, `2`, `3`
- Eye toggle — hide/show path in preview AND export
- **Implementation note:** sequence drives the animation `order` index used in stagger calculation. Drop-target highlights with violet border.

### F8 · Per-path color picker 🟢 LOCKED
Click any path's color swatch in the sidebar list to open an inline palette.
- 10-swatch palette (white, brand colors, neutrals)
- Click a swatch to apply
- (Future: hex input field, eyedropper)

### F2 · Scrub timeline 🟢 LOCKED
Single horizontal bar above the playback controls. Drag the playhead to scrub the animation. **No keyframes, no tracks** — just a position scrubber, like a video player.
- Tick labels: 0.0s, 25%, 50%, 75%, total
- Pauses playback when user grabs the playhead
- Playhead is a 16×18 white rounded rect with 2px violet border, shadow

### F9 · Loop mode 🟢 LOCKED
Three-way segmented control next to play button: `Once / Loop / Ping-pong`.
- **Once:** play, hold last frame
- **Loop:** restart from frame 1
- **Ping-pong:** forward, then reverse, repeat
- **Affects preview only.** Export always renders one forward pass — looping is up to whoever uses the file.

### F11 · Split compare 🟢 LOCKED
DaVinci-style A/B view of static original vs animated.
- Floating button bottom-right of preview area to toggle
- Draggable vertical divider in the preview when split is on
- Labels: "Original" (left) and "Animated" (right)
- Original side shows the SVG fully rendered with desaturated colors

### F10 · Keyboard shortcuts 🟢 LOCKED
Press `?` (Shift + /) to toggle an overlay listing all bindings. Three columns:
- **Playback:** Space, R, ← / →, Shift ← / →
- **File:** ⌘O, ⌘E, ⌘⇧E, ⌘⌫
- **View:** 1 / 2 / 3 (formats), L (loop), S (split), ?

Shortcuts are ignored when an `<input>` or `<textarea>` is focused.

---

## 4. Features — parked for later 🟡

These were prototyped but pushed out of v1.

### F7 · Quick copy formats 🟡 PARKED
Dropdown next to Export button: `Copy as ▾`. Six formats:
- CSS @keyframes
- Lottie JSON
- Python · MoviePy script
- SVG SMIL (self-contained animated SVG)
- GIF · 720p (link)
- MOV · 1080p alpha (link)

Each row shows shortcut hint (`⌘C`, `⌘L`, etc.), copies to clipboard, and shows a toast `✓ <name> copied to clipboard`.

**Why parked:** GIF/MOV require server-side render (or wasm encoder); CSS/Lottie/Python/SMIL are clipboard-only and easier to ship first.

**Recommendation when re-introducing:** ship the four clipboard-only formats first as a `Copy as ▾` dropdown next to Export. Add GIF/MOV once render pipeline is in place.

---

## 5. Features — dropped ❌

Considered and rejected. Logged here so we don't re-litigate.

| Feature | Why dropped |
|---|---|
| **F3 · Animation presets** (Logo reveal, Handwritten, Pop in, Trace & fill, Bounce) | Too prescriptive. Smart defaults (F6) covers the "I don't want to think" case better, and presets clutter the sidebar. |
| **F12 · Save preset** (custom user-named preset library) | Requires backend / persistence. Defer until accounts exist. |
| **F4 · Recent files / dashboard** | Requires backend. Build with auth phase. |
| **AI auto-tune** (was earlier in sidebar) | Removed — overlapped with smart defaults and felt buzzword-y. |

---

## 6. Editor design alternatives — explored but not chosen

We explored 11+ visual directions before locking in "light hybrid #1". For reference:

- **Clean default** — refined DaisyUI dark
- **Brutalist mono** — sharp borders, all-caps mono
- **Glass / Aurora** — frosted panels over gradient blobs
- **Paper light** — warm cream, italic serif, editorial
- **Terminal CRT** — green-on-black, scanlines
- **Neo-skeu tactile** — soft shadows, dimensional buttons
- **Magazine grid** — bold serif headline, asymmetric layout
- **Cyber neon** — cyan/magenta glow, grid backdrop
- **Minimal wireframe** — pure outline, blueprint feel
- **Pro tool / DAW** — dense Figma/Logic-style with timeline + inspector
- **Evervault moody / Wope pastel / Freepik mesh hero / Inverted editorial / Vibrant glass** — refined-round candidates

The chosen direction (#1) takes the gradient richness from the saturated options (mesh hero, glass) and applies it as a hero band on a clean white workspace, so the gradient anchors brand identity without overwhelming the editing surface.

---

## 7. Logo alternatives — explored but not chosen

We tested 4 final hybrids of three earlier shortlisted concepts (A2 inline arc, E1 dot suffix, E2 wordmark + slash):

- **A2** (inline arc replaces letter) — **CHOSEN**
- **A2 + E1** (inline arc + gradient dot suffix)
- **E2** (wordmark with gradient slash)
- **A2 bold capital** (most app-icon-ready)

Earlier rounds: ~30 logo concepts spanning monogram, geometric, abstract, gradient orb, animated stroke, etc.

---

## 8. Feature interactions / edge cases

### F1 + F8 (path reorder + color)
The path color swatch in the path list is the *same* clickable element that opens the color picker. This means dragging a row doesn't accidentally open colors (drag is initiated from the drag handle on the left, not the swatch).

### F2 + F9 (scrub + loop)
Scrubbing while loop mode is `loop` or `pingpong` should pause playback. Releasing the scrubber leaves the playhead at that position — user has to press play to resume.

### F6 + F1 (smart defaults + reorder)
Smart defaults sets `stagger` and `drawDur`. Reordering paths doesn't change those values — order only changes which path animates *first*. Toggling smart defaults off → on should re-tune to the current path count.

### F11 (split compare)
When split is on, the loop mode and scrubber still work; the animated half plays through, the original half stays static. This is correct — split is for visualizing the *delta*, not for editing.

### F10 + everything (keyboard)
- `Space`, `R` toggle play/replay
- `1/2/3` swap format
- `L` cycles loop modes
- `S` toggles split
- All shortcuts noop when typing in an input

---

## 9. Original logic to preserve (from `Trace.html`)

The first working prototype (`Trace.html`, before the redesign) had real logic for:
- SVG file parsing (path extraction, stroke/fill detection)
- Two-phase animation (stroke draw → fill bloom)
- Code generation (CSS keyframes + Python script string)
- Syntax highlighting in the export modal
- Color sync between stroke/fill picker and preview
- Transparent → MOV export

When wiring up the real backend, **preserve all of this**. The redesigned UI in `Trace Demo.html` is a presentation layer; the logic from the v1 file is the engine.

---

## 10. Files in this project

| File | Purpose |
|---|---|
| `Trace Demo.html` | **Working demo with all 8 locked-in features.** Demonstrates UX flow but not real export. |
| `Trace Logo Handoff.html` | Illustrator handoff for the A2 logo: SVG downloads, color/type/geometry specs, build steps, do's & don'ts |
| `Trace Final Round.html` | The 4 light gradient editor directions and 4 logo hybrids — final exploration round before lock-in |
| `Trace UX Features.html` | The 11 isolated UX feature demos (each on its own artboard) |
| `Trace Spec.html` | This document |

---

## 11. Suggested next steps

1. **Wire backend / render pipeline.** Pick MOV/GIF encoder (wasm or server-side). Lottie + CSS + Python are clipboard-only.
2. **Real SVG parsing.** Replace the 4 hard-coded sample SVGs with real `<input type="file">` → DOMParser → walk paths.
3. **Per-path delay slider.** F1's row currently shows order index. Add a per-row delay knob for fine-grained control.
4. **Re-introduce F7** (Copy formats) as soon as 4 clipboard formats render correctly.
5. **Authentication phase** unlocks F4 (recent files), F12 (saved presets), and a dashboard view.
6. **Performance:** For files with >20 paths, throttle the path list render and debounce slider drags.
7. **Accessibility audit:** Sliders need keyboard support (already have arrow-key handling at the app level, but per-slider focus + arrows should also work). Color picker swatches need ARIA labels.

---

*Last updated as of locking in F1, F2, F5, F6, F8, F9, F10, F11.*
