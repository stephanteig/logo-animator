# Handoff: Trace

> **For Claude Code (web).** Read this file first, then `Trace Spec.md`, then open `Trace Demo.html` in a browser to see the working prototype before writing any code.

---

## What you're building

**Trace** — a web tool that turns a static SVG logo into a stroke-by-stroke animated reveal. User drops an SVG, tweaks timing in a sidebar, exports to MOV / GIF / Lottie / CSS / Python.

The MVP is the **editor experience** captured in `Trace Demo.html`. All eight features in that demo are locked. Render pipeline (MOV/GIF) is parked — see Spec §4.

## Files in this bundle

| File | Purpose |
|---|---|
| `README.md` | This file — start here |
| `Trace Spec.md` | Full product spec — features, tokens, edge cases, parked work |
| `Trace Demo.html` | **Hi-fi working prototype.** Open in a browser. This is the ground truth for layout, type, color, interaction. |
| `demo/app.jsx` | The React source for the demo, so you can read exact component structure / state |
| `Trace Logo Handoff.html` | Logo brand guide — colors, geometry, clear space, do's & don'ts |
| `assets/trace_logo.svg` | **Final production logo (use this).** Custom-drawn wordmark with the "a" replaced by an arc + dot. |
| `assets/trace_logo@4x.png` | 4× PNG raster of the final logo for embedded previews |
| `assets/trace_logo@4x.jpg` | 4× JPG version (white background) for documents that don't support transparency |
| `assets/logo-on-dark.svg` | Earlier prototype version on dark surface — reference only, **don't use** |
| `assets/logo-on-light.svg` | Earlier prototype version on light surface — reference only, **don't use** |
| `assets/mark-only.svg` | Earlier prototype mark — reference only, **don't use** |

### Logo note (read this)

The wordmark went through several iterations. The **final production logo is `assets/trace_logo.svg`** — a custom-drawn wordmark where the "a" is replaced by an inverted arc with a pink dot at its right anchor. The arc uses the same violet→pink gradient (`#a78bfa → #ec4899`).

**Wordmark typeface: Inter Medium (500).** This is a deliberate change from the earlier prototype (which used Geist). Colors, gradient, arc/dot geometry are unchanged — only the letterform font is now Inter. If you need to recreate or extend the wordmark in code (e.g. responsive sizing, different colors, animation), use **Inter 500** for the letters `t`, `r`, `c`, `e`, with the gradient arc + pink dot as a separate inline SVG element replacing the `a`.

> Note: this also means **Inter** joins the type system as the brand wordmark font. UI body type is still **Geist** (per Spec §2). Don't replace Geist with Inter elsewhere — Inter is logo-only.

The prototype HTML files (`Trace Demo.html`, `Trace Logo Handoff.html`) still reference the earlier hand-drawn Geist-based version — **ignore those for the final brand**. Use `trace_logo.svg` everywhere a logo appears in the real app: nav bar, hero band, favicon, social cards, exports.

If you need a mark-only / app-icon version, lift the arc + dot subgroup out of `trace_logo.svg` (the `<path class="cls-2">` and `<circle class="cls-3">` inside `<symbol id="Trace-Logo">`).

## About these files (important)

The HTML/JSX in this bundle is a **design reference**, not production code. It's a Babel-in-the-browser React prototype with hard-coded sample SVGs and fake export — built to show *what to build* and *how it should feel*, not to ship.

**Your job:** recreate this design in the target codebase using its conventions (framework, component library, styling system, build tooling). If there is no codebase yet, set one up — recommended stack at the bottom of this doc.

The prototype is **high-fidelity**: pixel-perfect colors, type, spacing, and interactions. Match it exactly. Don't substitute fonts, don't redraw the gradients, don't change the slider style.

## Tech stack recommendation (if starting fresh)

- **Next.js 15** (App Router) + **TypeScript**
- **Tailwind CSS 4** with custom tokens matching Spec §2
- **Geist + Geist Mono** via `next/font/google` or `geist` package
- **Instrument Serif** via `next/font/google`
- **Radix UI** primitives for sliders, dropdowns, dialogs (then style to match)
- **Framer Motion** for the animation engine and split-compare drag
- Client-side SVG parse via `DOMParser` (no server required for v1)
- Deploy: Vercel

Render pipeline (deferred): server function or wasm encoder for MOV/GIF — see Spec §4 / §11.

## Implementation order

Work in this order. Don't try to build everything in parallel.

1. **Tokens + global CSS.** Set up CSS variables from Spec §2 ("Color tokens"). Wire fonts. Establish base typography (body = Geist 14px, mono labels = uppercase Geist Mono 11px / letter-spacing 1.4).
2. **Logo component.** SVG inline, gradient defs, both surfaces. Reusable.
3. **Layout shell.** Hero band (gradient `135deg, #1e1b4b → #4c1d95 → #831843` + violet/pink radial halos blurred 40px) + 320px sidebar + workspace with subtle 32×32 grid.
4. **Empty state (F5).** Italic Instrument Serif headline `animate logos like they breathe`. Dropzone is the workspace. 4 sample SVGs below — clicking one loads it as if it were uploaded. Drop a real SVG also works.
5. **SVG parser.** Use `DOMParser` to walk an uploaded SVG, extract `<path>`s (and `<line>`, `<polyline>`, `<polygon>` converted to path d). Read `id`/`title` for names, fall back to "Path 1", etc. Store stroke + fill from the source.
6. **Path list (F1 + F8).** Sidebar list of detected paths. Drag handle on left, swatch (clickable → inline picker) middle-left, name middle, mono index right, eye toggle right edge. Reorder via drag updates the order index used for stagger.
7. **Animation engine.** Two-phase: stroke-draw (using `stroke-dasharray` + `stroke-dashoffset` from path total length) then fill-bloom (opacity 0 → 1). Stagger between paths driven by sidebar order. RAF loop with elapsed time as source of truth so scrubbing works.
8. **Sliders.** Custom-styled (Spec §2) — gradient fill, white 12px thumb with shadow + halo. Sliders for: draw duration, fill start, hold, stagger.
9. **Smart defaults (F6).** Toggle. When on + on file load, run heuristic from Spec §3 ("F6 tuning rules"). When off, defaults are static.
10. **Scrub timeline (F2).** Single bar above transport. Drag playhead → set animation elapsed time, pause playback. Tick labels at 0 / 25% / 50% / 75% / total.
11. **Loop mode (F9).** Three-way segmented control. Affects preview only. Once = freeze on last frame. Loop = restart. Ping-pong = reverse → restart.
12. **Split compare (F11).** Floating button bottom-right of preview. When on, render two stacked SVGs in the same preview frame: left half = original (desaturated, fully drawn, no animation), right half = animated. Vertical divider draggable to slide where the split happens.
13. **Keyboard shortcuts (F10).** Global keydown listener; ignore when focus is in input/textarea. `?` opens overlay modal. Bindings in Spec §3 (F10) and §8 (F10 + everything).
14. **Export modal.** Tabs: CSS @keyframes, Python (MoviePy), Lottie JSON. Generate from current state. Syntax highlight. "Copy" button + toast. (MOV/GIF disabled with "coming soon" tag — see Spec §4.)

After step 14 ship a v1. Spec §11 has follow-on work.

## Pixel-perfect things you must NOT redesign

- **Logo geometry.** Path data, stroke widths, gradient angles all in `Trace Logo Handoff.html`. Use the SVG files in `assets/` as-is.
- **Hero gradient.** Exact stops at `#1e1b4b 0%, #4c1d95 35%, #831843 100%` with two radial halos (violet @ 30% 40% + pink @ 70% 60%, both `rgba(_, 0.4)`, blur 40px).
- **Sidebar width.** 320px. Workspace fills the rest.
- **Mono labels.** Always `text-transform: uppercase`, `letter-spacing: 1.4px`, `font-size: 11px`, `color: var(--ink-300)`.
- **Slider thumb.** 12×12 white circle, `box-shadow: 0 0 0 2px var(--violet-500), 0 4px 12px rgba(124,58,237,0.4)`. Track has gradient fill from violet → pink for the filled portion.
- **Preview surface.** `#0d0b18` rounded 18px, conic gradient halo behind (blur 70px, opacity 0.3).

## Design tokens reference

Pull these into your CSS. Full list in Spec §2.

```css
:root {
  --violet-500: #7c3aed;
  --violet-400: #a78bfa;
  --pink-500:   #ec4899;
  --ink:        #0a0a14;
  --ink-700:    #3f3f46;
  --ink-500:    #71717a;
  --ink-300:    #a1a1aa;
  --surface:    #ffffff;
  --surface-2:  #fafafa;
  --surface-3:  #f4f4f5;
  --border:     #ededed;
  --canvas-dark:#0d0b18;
  --success:    #10b981;

  --gradient-brand: linear-gradient(135deg, #a78bfa 0%, #ec4899 100%);
  --gradient-hero:  linear-gradient(135deg, #1e1b4b 0%, #4c1d95 35%, #831843 100%);
}
```

## State model

Roughly what the editor needs (TypeScript):

```ts
type Path = {
  id: string;
  name: string;       // from SVG id/title or "Path N"
  d: string;
  stroke: string;
  fill: string;
  visible: boolean;
  order: number;      // index in animation sequence
};

type Anim = {
  drawDur: number;       // seconds, default 2.4
  fillStart: number;     // seconds, default 1.0
  hold: number;          // seconds, default 0.6
  stagger: number;       // seconds between paths, default 0.18
};

type EditorState = {
  paths: Path[];
  anim: Anim;
  smartDefaults: boolean;
  loop: 'once' | 'loop' | 'pingpong';
  split: boolean;
  splitPos: number;          // 0..1
  playing: boolean;
  elapsed: number;           // animation time, drives scrubber
};
```

Total animation duration = `drawDur + max(fillStart + bloomDur, hold) + stagger * (paths.length - 1)`.

## Edge cases & interactions

Spec §8 covers these. The non-obvious ones:

- Reordering paths doesn't retune timing — only changes which path animates first.
- Smart defaults off → on should re-tune to current path count.
- Scrubbing while loop = `loop` or `pingpong` pauses playback. User must press play to resume.
- Split compare: animated half plays, original half is static + desaturated.
- `?` shortcut overlay should be dismissable with `Esc` and by clicking the backdrop.

## What's parked / out of scope for v1

- F7 Quick copy formats (full dropdown UX is designed; clipboard formats only when re-introduced)
- F12 Save preset library — needs auth
- F4 Recent files / dashboard — needs auth
- MOV/GIF render pipeline — needs encoder

See Spec §4 and §11 for re-introduction notes.

## Questions / unknowns

If anything is ambiguous, **prefer the prototype's behavior**. If the prototype itself is unclear, leave a `// TODO(trace):` comment with what you decided and why, rather than guessing silently.

---

*If you can answer "does my screen match `Trace Demo.html` pixel-for-pixel?" with yes for every screen and state, you've nailed it.*
