/* global React, ReactDOM */
const { useState, useRef, useEffect, useCallback } = React;

// ============================================================
// CONSTANTS & ICONS
// ============================================================
const SAMPLES = {
  geometric: {
    name: 'Geometric',
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <path d="M40 160 L100 40 L160 160" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M70 130 L130 130" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
      <circle cx="100" cy="100" r="22" fill="#a78bfa"/>
    </svg>`,
    paths: [
      { id: 'p1', name: 'Triangle outline', color: '#ffffff', kind: 'stroke' },
      { id: 'p2', name: 'Crossbar',         color: '#ffffff', kind: 'stroke' },
      { id: 'p3', name: 'Inner circle',     color: '#a78bfa', kind: 'fill'   },
    ],
  },
  monogram: {
    name: 'Monogram',
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <circle cx="100" cy="100" r="70" fill="none" stroke="#ffffff" stroke-width="3"/>
      <path d="M70 130 L70 70 L130 130 L130 70" fill="none" stroke="#ec4899" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`,
    paths: [
      { id: 'p1', name: 'Circle frame', color: '#ffffff', kind: 'stroke' },
      { id: 'p2', name: 'Letter N',     color: '#ec4899', kind: 'stroke' },
    ],
  },
  icon: {
    name: 'Checkmark',
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <path d="M50 100 L85 135 L150 60" fill="none" stroke="#10b981" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`,
    paths: [
      { id: 'p1', name: 'Check', color: '#10b981', kind: 'stroke' },
    ],
  },
  star: {
    name: 'Star burst',
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <path d="M100 20 L120 80 L185 80 L132 118 L152 178 L100 140 L48 178 L68 118 L15 80 L80 80 Z" fill="none" stroke="#fbbf24" stroke-width="3" stroke-linejoin="round"/>
      <circle cx="100" cy="100" r="14" fill="#fbbf24"/>
    </svg>`,
    paths: [
      { id: 'p1', name: 'Star outline', color: '#fbbf24', kind: 'stroke' },
      { id: 'p2', name: 'Center dot',   color: '#fbbf24', kind: 'fill'   },
    ],
  },
};

const PALETTE = ['#ffffff','#a78bfa','#ec4899','#f59e0b','#06b6d4','#10b981','#f43f5e','#fbbf24','#0a0a14','#525252'];

const Icon = {
  download: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  play: (p={}) => <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" {...p}><polygon points="6 4 20 12 6 20 6 4"/></svg>,
  pause: (p={}) => <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" {...p}><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
  replay: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>,
  drag: (p={}) => <svg width="10" height="14" viewBox="0 0 10 14" fill="currentColor" {...p}><circle cx="2" cy="2" r="1.2"/><circle cx="2" cy="7" r="1.2"/><circle cx="2" cy="12" r="1.2"/><circle cx="8" cy="2" r="1.2"/><circle cx="8" cy="7" r="1.2"/><circle cx="8" cy="12" r="1.2"/></svg>,
  eye: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
  eyeOff: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>,
  upload: (p={}) => <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  sparkle: (p={}) => <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M12 2L13.5 8.5L20 10L13.5 11.5L12 18L10.5 11.5L4 10L10.5 8.5L12 2Z"/></svg>,
  once: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="5 3 19 12 5 21 5 3"/></svg>,
  loop: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>,
  pingpong: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="2 12 6 8 6 16 2 12"/><polyline points="22 12 18 8 18 16 22 12"/><line x1="6" y1="12" x2="18" y2="12"/></svg>,
  split: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="12" y1="3" x2="12" y2="21"/></svg>,
  keyboard: (p={}) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="2" y="4" width="20" height="16" rx="2"/><line x1="6" y1="8" x2="6.01" y2="8"/><line x1="10" y1="8" x2="10.01" y2="8"/><line x1="14" y1="8" x2="14.01" y2="8"/><line x1="18" y1="8" x2="18.01" y2="8"/><line x1="6" y1="12" x2="6.01" y2="12"/><line x1="18" y1="12" x2="18.01" y2="12"/><line x1="7" y1="16" x2="17" y2="16"/></svg>,
  close: (p={}) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"{...p}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
};

// ============================================================
// SHARED ATOMS
// ============================================================
function TraceWordmark({ size=18, color='#fff' }) {
  const id = 'tw-' + size;
  return (
    <div style={{ display: 'flex', alignItems: 'center', fontFamily: 'Geist, system-ui', fontSize: size, fontWeight: 600, color, letterSpacing: -0.6 }}>
      <span>tr</span>
      <svg width={size*0.78} height={size*0.78} viewBox="0 0 48 48" style={{ margin: '0 -1px' }}>
        <defs><linearGradient id={id} x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stopColor="#a78bfa"/><stop offset="100%" stopColor="#ec4899"/></linearGradient></defs>
        <path d="M8 36 Q24 6, 40 36" fill="none" stroke={`url(#${id})`} strokeWidth="5" strokeLinecap="round"/>
        <circle cx="40" cy="36" r="4.5" fill="#ec4899"/>
      </svg>
      <span>ce</span>
    </div>
  );
}

function HeroBand({ children }) {
  return (
    <div style={{ height: 56, background: 'linear-gradient(135deg, #1e1b4b 0%, #4c1d95 35%, #831843 100%)', position: 'relative', overflow: 'hidden', flexShrink: 0 }}>
      <div style={{ position: 'absolute', width: 700, height: 240, left: -100, top: -50, background: 'radial-gradient(ellipse, rgba(167,139,250,0.6) 0%, transparent 60%)', filter: 'blur(40px)' }}/>
      <div style={{ position: 'absolute', width: 700, height: 240, right: -100, top: -50, background: 'radial-gradient(ellipse, rgba(244,114,182,0.5) 0%, transparent 60%)', filter: 'blur(40px)' }}/>
      <div style={{ position: 'relative', height: '100%', padding: '0 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>{children}</div>
    </div>
  );
}

function Slider({ label, val, value, min=0, max=100, onChange }) {
  const pct = ((value - min) / (max - min)) * 100;
  const ref = useRef(null);
  const startDrag = (e) => {
    e.preventDefault();
    const rect = ref.current.getBoundingClientRect();
    const update = (ev) => {
      const x = (ev.clientX - rect.left) / rect.width;
      const v = min + Math.max(0, Math.min(1, x)) * (max - min);
      onChange && onChange(v);
    };
    update(e);
    const up = () => { window.removeEventListener('mousemove', update); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', update);
    window.addEventListener('mouseup', up);
  };
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', fontSize: 11.5, marginBottom: 7 }}>
        <span style={{ color: 'rgba(15,23,42,0.6)' }}>{label}</span>
        <span style={{ fontFamily: 'Geist Mono, monospace', color: '#0f172a', fontSize: 10.5, fontWeight: 500 }}>{val}</span>
      </div>
      <div ref={ref} onMouseDown={startDrag} style={{ height: 14, position: 'relative', cursor: 'pointer' }}>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 5, height: 4, background: 'rgba(15,23,42,0.08)', borderRadius: 99 }}>
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${pct}%`, background: 'linear-gradient(90deg,#7c3aed,#ec4899)', borderRadius: 99 }}/>
        </div>
        <div style={{ position: 'absolute', left: `calc(${pct}% - 6px)`, top: 1, width: 12, height: 12, borderRadius: 99, background: '#fff', boxShadow: '0 2px 6px rgba(0,0,0,0.12), 0 0 0 4px rgba(15,23,42,0.04)' }}/>
      </div>
    </div>
  );
}

// ============================================================
// PREVIEW (renders the SVG with animation based on time + paths)
// ============================================================
function AnimatedPreview({ paths, time, sample, size=440, frozen=false }) {
  // path-by-path stagger; each path gets its own animation window
  // duration normalized to 0..1
  const visiblePaths = paths.filter(p => p.visible !== false);
  const stagger = 1 / Math.max(visiblePaths.length, 1);
  return (
    <div style={{ position: 'relative' }}>
      <div style={{ position: 'absolute', inset: -50, background: 'conic-gradient(from 180deg at 50% 50%, #a78bfa, #ec4899, #f59e0b, #06b6d4, #a78bfa)', filter: 'blur(70px)', opacity: 0.3, borderRadius: '50%' }}/>
      <div style={{ position: 'relative', width: size, height: size, background: '#0d0b18', borderRadius: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.06)', overflow: 'hidden' }}>
        <svg viewBox="0 0 200 200" style={{ width: '60%', height: '60%' }}>
          {sample === 'geometric' && <>
            <Path d="M40 160 L100 40 L160 160" path={visiblePaths.find(p=>p.id==='p1')} order={0} time={time} stagger={stagger} sw={3}/>
            <Path d="M70 130 L130 130"        path={visiblePaths.find(p=>p.id==='p2')} order={1} time={time} stagger={stagger} sw={3}/>
            <PathCircle cx="100" cy="100" r="22" path={visiblePaths.find(p=>p.id==='p3')} order={2} time={time} stagger={stagger}/>
          </>}
          {sample === 'monogram' && <>
            <PathCircleStroke cx="100" cy="100" r="70" path={visiblePaths.find(p=>p.id==='p1')} order={0} time={time} stagger={stagger} sw={3}/>
            <Path d="M70 130 L70 70 L130 130 L130 70" path={visiblePaths.find(p=>p.id==='p2')} order={1} time={time} stagger={stagger} sw={4}/>
          </>}
          {sample === 'icon' && <>
            <Path d="M50 100 L85 135 L150 60" path={visiblePaths.find(p=>p.id==='p1')} order={0} time={time} stagger={stagger} sw={6}/>
          </>}
          {sample === 'star' && <>
            <Path d="M100 20 L120 80 L185 80 L132 118 L152 178 L100 140 L48 178 L68 118 L15 80 L80 80 Z" path={visiblePaths.find(p=>p.id==='p1')} order={0} time={time} stagger={stagger} sw={3}/>
            <PathCircle cx="100" cy="100" r="14" path={visiblePaths.find(p=>p.id==='p2')} order={1} time={time} stagger={stagger}/>
          </>}
        </svg>
      </div>
    </div>
  );
}

function pathProgress(time, order, stagger) {
  const start = order * stagger;
  const local = (time - start) / stagger;
  return Math.max(0, Math.min(1, local));
}

function Path({ d, path, order, time, stagger, sw=3 }) {
  if (!path) return null;
  const ref = useRef(null);
  const [len, setLen] = useState(500);
  useEffect(() => { if (ref.current) setLen(ref.current.getTotalLength()); }, [d]);
  const p = pathProgress(time, order, stagger);
  if (path.kind === 'stroke') {
    return <path ref={ref} d={d} fill="none" stroke={path.color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={len} strokeDashoffset={len * (1 - p)}/>;
  }
  return <path ref={ref} d={d} fill={path.color} opacity={p}/>;
}
function PathCircle({ cx, cy, r, path, order, time, stagger }) {
  if (!path) return null;
  const p = pathProgress(time, order, stagger);
  return <circle cx={cx} cy={cy} r={Number(r) * p} fill={path.color}/>;
}
function PathCircleStroke({ cx, cy, r, path, order, time, stagger, sw=3 }) {
  if (!path) return null;
  const p = pathProgress(time, order, stagger);
  const C = 2 * Math.PI * Number(r);
  return <circle cx={cx} cy={cy} r={r} fill="none" stroke={path.color} strokeWidth={sw} strokeDasharray={C} strokeDashoffset={C * (1 - p)} transform={`rotate(-90 ${cx} ${cy})`}/>;
}

// ============================================================
// EMPTY STATE (Feature 5)
// ============================================================
function EmptyState({ onPick }) {
  const [drag, setDrag] = useState(false);
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: 700, height: 500, left: '-10%', top: '-20%', background: 'radial-gradient(ellipse, rgba(196,181,253,0.4) 0%, transparent 60%)', filter: 'blur(80px)' }}/>
      <div style={{ position: 'absolute', width: 700, height: 500, right: '-10%', bottom: '-20%', background: 'radial-gradient(ellipse, rgba(251,207,232,0.4) 0%, transparent 60%)', filter: 'blur(80px)' }}/>
      <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', maxWidth: 720 }}>
        <h1 style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', fontSize: 56, fontWeight: 400, margin: '0 0 12px', letterSpacing: -1.2, lineHeight: 1.05, color: '#0a0a14' }}>
          animate <span style={{ background: 'linear-gradient(135deg,#7c3aed,#ec4899)', WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>logos</span> like they breathe
        </h1>
        <p style={{ fontSize: 15, color: '#525252', maxWidth: 460, margin: '0 0 32px', lineHeight: 1.5 }}>Drop an SVG and Trace will draw it stroke-by-stroke, then export to MOV, GIF, or Lottie.</p>
        <div onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); onPick('geometric'); }}
          style={{ width: 520, padding: 32, border: '2px dashed '+(drag?'#7c3aed':'rgba(124,58,237,0.4)'), borderRadius: 18, background: drag?'rgba(124,58,237,0.05)':'rgba(255,255,255,0.6)', backdropFilter: 'blur(12px)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, cursor: 'pointer', transition: 'all 0.15s' }}
          onClick={() => onPick('geometric')}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: 'linear-gradient(135deg, rgba(124,58,237,0.1), rgba(236,72,153,0.1))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7c3aed' }}><Icon.upload/></div>
          <div style={{ fontSize: 15, fontWeight: 500 }}>Drop your SVG here</div>
          <div style={{ fontSize: 12, color: '#71717a' }}>or click to browse · max 2MB · single file</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, margin: '28px 0 14px' }}>
          <span style={{ height: 1, width: 60, background: '#ededed' }}/>
          <span style={{ fontSize: 11, color: '#a1a1aa', fontFamily: 'Geist Mono, monospace', textTransform: 'uppercase', letterSpacing: 1.4 }}>or try a sample</span>
          <span style={{ height: 1, width: 60, background: '#ededed' }}/>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {Object.entries(SAMPLES).map(([k, s]) => (
            <button key={k} onClick={() => onPick(k)} style={{ padding: '10px 14px', background: '#fff', border: '1px solid #ededed', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontFamily: 'inherit' }}>
              <span style={{ width: 32, height: 32, background: '#0d0b18', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span dangerouslySetInnerHTML={{ __html: s.svg.replace('width="200"','').replace('height="200"','').replace('<svg ', '<svg width="22" height="22" ') }}/>
              </span>
              <span style={{ fontSize: 12, color: '#3f3f46', fontWeight: 500 }}>{s.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// KEYBOARD OVERLAY (Feature 10)
// ============================================================
function KeyboardOverlay({ onClose }) {
  const groups = [
    { title: 'Playback', items: [['Space','Play / pause'],['R','Replay from start'],['← / →','Step ±0.1s'],['⇧ ← / →','Jump to start / end']] },
    { title: 'File',     items: [['⌘ O','Open SVG'],['⌘ E','Export'],['⌘ ⇧ E','Re-export last'],['⌘ ⌫','Clear file']] },
    { title: 'View',     items: [['1 / 2 / 3','Format 1:1 / 16:9 / 9:16'],['L','Toggle loop mode'],['S','Toggle split compare'],['?','Toggle this overlay']] },
  ];
  const kbd = { fontFamily: 'Geist Mono, monospace', fontSize: 10.5, padding: '2px 6px', background: '#fafafa', border: '1px solid #ededed', borderBottom: '2px solid #ededed', borderRadius: 4, color: '#0a0a14', minWidth: 20, textAlign: 'center', display: 'inline-block' };
  return (
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(10,10,20,0.4)', backdropFilter: 'blur(2px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
      <div onClick={e => e.stopPropagation()} style={{ width: 600, background: '#fff', borderRadius: 16, boxShadow: '0 30px 80px -20px rgba(0,0,0,0.4)', overflow: 'hidden' }}>
        <div style={{ padding: '18px 22px', borderBottom: '1px solid #f4f4f5', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, fontWeight: 500 }}><Icon.keyboard/> Keyboard shortcuts</div>
            <div style={{ fontSize: 11.5, color: '#71717a', marginTop: 4 }}>Press <span style={kbd}>?</span> any time to toggle</div>
          </div>
          <button onClick={onClose} style={{ width: 28, height: 28, borderRadius: 6, background: '#fafafa', border: '1px solid #ededed', cursor: 'pointer', color: '#71717a', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon.close/></button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr' }}>
          {groups.map((g, i) => (
            <div key={g.title} style={{ padding: '16px 18px', borderRight: i<2 ? '1px solid #f4f4f5' : 'none' }}>
              <div style={{ fontSize: 10.5, letterSpacing: 1.3, textTransform: 'uppercase', color: '#a1a1aa', fontWeight: 600, marginBottom: 12 }}>{g.title}</div>
              {g.items.map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontSize: 11.5, color: '#3f3f46' }}>{v}</span>
                  <span style={kbd}>{k}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// MAIN APP
// ============================================================
function App() {
  const [sample, setSample] = useState(null);
  const [paths, setPaths] = useState([]);
  const [time, setTime] = useState(0.5);
  const [playing, setPlaying] = useState(false);
  const [loopMode, setLoopMode] = useState('once'); // once | loop | pingpong
  const [direction, setDirection] = useState(1);
  const [smartDefaults, setSmartDefaults] = useState(true);
  const [split, setSplit] = useState(false);
  const [splitPos, setSplitPos] = useState(50);
  const [showKbd, setShowKbd] = useState(false);
  const [drawDur, setDrawDur] = useState(2.5);
  const [fillDur, setFillDur] = useState(1.0);
  const [stagger, setStagger] = useState(0.15);
  const [hold, setHold] = useState(0.8);
  const [dragId, setDragId] = useState(null);
  const [colorOpen, setColorOpen] = useState(null);
  const [format, setFormat] = useState('1:1');

  const totalDur = drawDur + (paths.length-1)*stagger + hold;

  const loadSample = (key) => {
    const s = SAMPLES[key];
    setSample(key);
    setPaths(s.paths.map(p => ({ ...p, visible: true })));
    if (smartDefaults) {
      // tune by path count
      const n = s.paths.length;
      setDrawDur(n <= 1 ? 1.8 : n <= 2 ? 2.2 : 2.8);
      setStagger(n <= 1 ? 0 : 0.18);
      setFillDur(1.0);
      setHold(0.6);
    }
    setTime(0);
  };

  // playback loop
  useEffect(() => {
    if (!playing) return;
    let raf, last = performance.now();
    const tick = (now) => {
      const dt = (now - last) / 1000;
      last = now;
      setTime(t => {
        let next = t + (dt / totalDur) * direction;
        if (loopMode === 'once') {
          if (next >= 1) { next = 1; setPlaying(false); }
        } else if (loopMode === 'loop') {
          if (next >= 1) next = 0;
        } else {
          if (next >= 1) { next = 1; setDirection(-1); }
          else if (next <= 0) { next = 0; setDirection(1); }
        }
        return next;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, loopMode, direction, totalDur]);

  // keyboard
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === '?' || (e.shiftKey && e.key === '/')) { e.preventDefault(); setShowKbd(s => !s); }
      else if (e.key === ' ') { e.preventDefault(); setPlaying(p => !p); }
      else if (e.key === 'r' || e.key === 'R') { setTime(0); setPlaying(true); setDirection(1); }
      else if (e.key === 'l' || e.key === 'L') { setLoopMode(m => m === 'once' ? 'loop' : m === 'loop' ? 'pingpong' : 'once'); }
      else if (e.key === 's' || e.key === 'S') { setSplit(s => !s); }
      else if (e.key === '1') setFormat('1:1');
      else if (e.key === '2') setFormat('16:9');
      else if (e.key === '3') setFormat('9:16');
      else if (e.key === 'ArrowLeft') setTime(t => Math.max(0, t - (e.shiftKey ? t : 0.05)));
      else if (e.key === 'ArrowRight') setTime(t => Math.min(1, t + (e.shiftKey ? 1-t : 0.05)));
      else if (e.key === 'Escape') setShowKbd(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const move = (from, to) => {
    if (from === to || from < 0) return;
    const next = [...paths];
    const [m] = next.splice(from, 1);
    next.splice(to, 0, m);
    setPaths(next);
  };

  // scrubber
  const barRef = useRef(null);
  const startScrub = (e) => {
    e.preventDefault();
    setPlaying(false);
    const rect = barRef.current.getBoundingClientRect();
    const update = (ev) => {
      const x = (ev.clientX - rect.left) / rect.width;
      setTime(Math.max(0, Math.min(1, x)));
    };
    update(e);
    const up = () => { window.removeEventListener('mousemove', update); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', update);
    window.addEventListener('mouseup', up);
  };

  // Empty state branch
  if (!sample) {
    return (
      <div style={{ width: '100%', height: '100vh', minHeight: 760, background: '#fff', fontFamily: 'Geist, system-ui', display: 'flex', flexDirection: 'column' }}>
        <HeroBand>
          <TraceWordmark/>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', fontFamily: 'Geist Mono, monospace' }}>no file</span>
        </HeroBand>
        <EmptyState onPick={loadSample}/>
        {showKbd && <KeyboardOverlay onClose={() => setShowKbd(false)}/>}
      </div>
    );
  }

  const cur = (time * totalDur).toFixed(2);
  const dur = totalDur.toFixed(2);
  const previewSize = format === '1:1' ? 440 : format === '16:9' ? 480 : 360;
  const previewH = format === '16:9' ? 270 : format === '9:16' ? 640 : previewSize;
  const previewW = format === '16:9' ? 480 : format === '9:16' ? 360 : previewSize;

  return (
    <div style={{ width: '100%', height: '100vh', minHeight: 760, background: '#fafafa', color: '#0a0a14', fontFamily: 'Geist, system-ui', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <HeroBand>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <TraceWordmark/>
          <nav style={{ display: 'flex', gap: 2, fontSize: 12.5 }}>
            {['Animation','Stroke','Background'].map((t,i)=>(<span key={t} style={{ padding: '5px 11px', borderRadius: 7, color: i===0?'#fff':'rgba(255,255,255,0.65)', background: i===0?'rgba(255,255,255,0.15)':'transparent', fontWeight: i===0?500:400, cursor: 'pointer' }}>{t}</span>))}
          </nav>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', fontFamily: 'Geist Mono, monospace' }}>{SAMPLES[sample].name.toLowerCase()}.svg · {paths.length} paths</span>
          <button onClick={() => setShowKbd(true)} title="Keyboard shortcuts (?)" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.12)', color: '#fff', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, fontSize: 11, fontFamily: 'Geist Mono, monospace', cursor: 'pointer' }}>?</button>
          <button onClick={() => { setSample(null); setPaths([]); }} style={{ background: 'rgba(255,255,255,0.12)', color: '#fff', border: '1px solid rgba(255,255,255,0.15)', padding: '6px 12px', borderRadius: 7, fontSize: 12, cursor: 'pointer' }}>New</button>
          <button style={{ background: '#fff', color: '#0a0814', border: 'none', padding: '7px 16px', borderRadius: 8, fontSize: 12.5, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}><Icon.download/> Export</button>
        </div>
      </HeroBand>
      <div style={{ flex: 1, display: 'flex', background: '#fff', overflow: 'hidden' }}>
        {/* SIDEBAR */}
        <aside style={{ width: 320, padding: '18px 20px', borderRight: '1px solid #ededed', display: 'flex', flexDirection: 'column', gap: 16, overflowY: 'auto' }}>
          {/* Smart defaults — Feature 6 */}
          <div style={{ padding: 12, background: smartDefaults?'linear-gradient(135deg, rgba(124,58,237,0.06), rgba(236,72,153,0.06))':'#fafafa', border: '1px solid '+(smartDefaults?'rgba(124,58,237,0.18)':'#ededed'), borderRadius: 10 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 500, color: smartDefaults?'#7c3aed':'#3f3f46' }}><Icon.sparkle/> Smart defaults</div>
                <div style={{ fontSize: 11, color: '#71717a', marginTop: 3, lineHeight: 1.4 }}>Auto-tune timing per file</div>
              </div>
              <button onClick={() => setSmartDefaults(!smartDefaults)} style={{ width: 32, height: 20, borderRadius: 99, background: smartDefaults?'#7c3aed':'#d4d4d8', border: 'none', position: 'relative', cursor: 'pointer', flexShrink: 0 }}>
                <span style={{ position: 'absolute', top: 2, left: smartDefaults?14:2, width: 16, height: 16, borderRadius: 99, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'left 0.15s' }}/>
              </button>
            </div>
          </div>

          {/* Format */}
          <div>
            <div style={{ fontSize: 10.5, letterSpacing: 1.4, textTransform: 'uppercase', color: '#a1a1aa', fontWeight: 600, marginBottom: 10 }}>Format</div>
            <div style={{ display: 'flex', padding: 3, background: '#f4f4f5', borderRadius: 8, gap: 2 }}>
              {['1:1','16:9','9:16'].map(r => (<button key={r} onClick={() => setFormat(r)} style={{ flex: 1, padding: '6px 0', fontSize: 12, background: format===r?'#fff':'transparent', borderRadius: 6, color: format===r?'#0a0a14':'#71717a', border: 'none', fontWeight: 500, boxShadow: format===r?'0 1px 2px rgba(0,0,0,0.06)':'none', cursor: 'pointer', fontFamily: 'inherit' }}>{r}</button>))}
            </div>
          </div>

          {/* Paths — Features 1 + 8 */}
          <div>
            <div style={{ fontSize: 10.5, letterSpacing: 1.4, textTransform: 'uppercase', color: '#a1a1aa', fontWeight: 600, marginBottom: 8, display: 'flex', justifyContent: 'space-between' }}>
              <span>Paths · drag to reorder</span><span style={{ fontFamily: 'Geist Mono, monospace' }}>{paths.length}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {paths.map((p, i) => (
                <div key={p.id}
                  draggable
                  onDragStart={() => setDragId(p.id)}
                  onDragOver={e => e.preventDefault()}
                  onDrop={() => { move(paths.findIndex(x => x.id === dragId), i); setDragId(null); }}
                  style={{ background: '#fff', border: '1px solid '+(dragId===p.id?'#a78bfa':colorOpen===p.id?'#a78bfa':'#ededed'), borderRadius: 8, opacity: p.visible?1:0.55 }}>
                  <div style={{ padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 8, cursor: 'grab' }}>
                    <span style={{ color: '#a1a1aa' }}><Icon.drag/></span>
                    <button onClick={() => setColorOpen(colorOpen===p.id ? null : p.id)} style={{ width: 22, height: 22, borderRadius: 5, background: p.color, border: '1px solid '+(p.color==='#ffffff'?'#ededed':'transparent'), boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.06)', cursor: 'pointer', padding: 0 }}/>
                    <span style={{ flex: 1, fontSize: 12, color: '#0a0a14' }}>{p.name}</span>
                    <span style={{ fontFamily: 'Geist Mono, monospace', fontSize: 10, color: '#71717a' }}>{i+1}</span>
                    <button onClick={() => setPaths(paths.map(x => x.id===p.id ? {...x, visible: !x.visible} : x))} style={{ background: 'none', border: 'none', color: p.visible?'#3f3f46':'#d4d4d8', cursor: 'pointer', padding: 2 }}>{p.visible ? <Icon.eye/> : <Icon.eyeOff/>}</button>
                  </div>
                  {colorOpen === p.id && (
                    <div style={{ padding: '0 10px 10px' }}>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, padding: 8, background: '#fafafa', borderRadius: 6 }}>
                        {PALETTE.map(c => (<button key={c} onClick={() => setPaths(paths.map(x => x.id===p.id ? {...x, color: c} : x))} style={{ width: 22, height: 22, borderRadius: 5, background: c, border: '2px solid '+(p.color===c?'#7c3aed':'transparent'), boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.08)', cursor: 'pointer', padding: 0 }}/>))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Timing */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ fontSize: 10.5, letterSpacing: 1.4, textTransform: 'uppercase', color: '#a1a1aa', fontWeight: 600 }}>Timing</div>
            <Slider label="Stroke draw" val={drawDur.toFixed(2)+'s'} value={drawDur} min={0.3} max={6} onChange={setDrawDur}/>
            <Slider label="Fill bloom" val={fillDur.toFixed(2)+'s'} value={fillDur} min={0} max={3} onChange={setFillDur}/>
            <Slider label="Path stagger" val={stagger.toFixed(2)+'s'} value={stagger} min={0} max={1} onChange={setStagger}/>
            <Slider label="Hold at end" val={hold.toFixed(2)+'s'} value={hold} min={0} max={3} onChange={setHold}/>
          </div>
        </aside>

        {/* MAIN CANVAS */}
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', backgroundImage: 'linear-gradient(rgba(0,0,0,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.025) 1px, transparent 1px)', backgroundSize: '32px 32px' }}>
            <div style={{ position: 'absolute', top: 14, left: 18, display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#71717a' }}><span style={{ width: 6, height: 6, borderRadius: 99, background: '#10b981' }}/>Live preview</div>
            <div style={{ position: 'absolute', top: 14, right: 18, fontSize: 12, fontFamily: 'Geist Mono, monospace', color: '#71717a' }}>{previewW} × {previewH}</div>

            {!split && <AnimatedPreview paths={paths} time={time} sample={sample} size={Math.min(previewW, previewH, 460)}/>}
            {split && (
              <div style={{ position: 'relative', width: 520, height: 460, borderRadius: 18, overflow: 'hidden', background: '#0d0b18' }}>
                <div style={{ position: 'absolute', inset: 0 }}>
                  <AnimatedPreview paths={paths} time={time} sample={sample} size={520}/>
                </div>
                <div style={{ position: 'absolute', inset: 0, clipPath: `inset(0 ${100-splitPos}% 0 0)`, background: '#0d0b18' }}>
                  <AnimatedPreview paths={paths.map(p => ({...p, color: p.kind==='fill'?'#666':'#888'}))} time={1} sample={sample} size={520}/>
                </div>
                <div style={{ position: 'absolute', top: 12, left: 12, padding: '4px 9px', background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(8px)', borderRadius: 6, fontSize: 10, fontFamily: 'Geist Mono, monospace', color: '#fff', textTransform: 'uppercase', letterSpacing: 1 }}>Original</div>
                <div style={{ position: 'absolute', top: 12, right: 12, padding: '4px 9px', background: 'rgba(124,58,237,0.6)', backdropFilter: 'blur(8px)', borderRadius: 6, fontSize: 10, fontFamily: 'Geist Mono, monospace', color: '#fff', textTransform: 'uppercase', letterSpacing: 1 }}>Animated</div>
                <div onMouseDown={(e) => {
                  const rect = e.currentTarget.parentElement.getBoundingClientRect();
                  const mv = (ev) => setSplitPos(Math.max(5, Math.min(95, ((ev.clientX - rect.left) / rect.width) * 100)));
                  const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); };
                  window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
                }} style={{ position: 'absolute', top: 0, bottom: 0, left: `${splitPos}%`, width: 2, background: '#fff', cursor: 'ew-resize' }}>
                  <div style={{ position: 'absolute', top: '50%', left: -16, width: 34, height: 34, borderRadius: 99, background: '#fff', transform: 'translateY(-50%)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 12px rgba(0,0,0,0.3)', fontSize: 12, color: '#0a0a14', fontWeight: 700 }}>⇆</div>
                </div>
              </div>
            )}

            <button onClick={() => setSplit(!split)} title="Split compare (S)" style={{ position: 'absolute', bottom: 14, right: 18, display: 'flex', alignItems: 'center', gap: 6, padding: '5px 11px', background: split?'rgba(124,58,237,0.95)':'#fff', color: split?'#fff':'#3f3f46', border: '1px solid '+(split?'transparent':'#ededed'), borderRadius: 7, fontSize: 11.5, fontFamily: 'inherit', cursor: 'pointer', fontWeight: 500, boxShadow: '0 4px 10px rgba(0,0,0,0.06)' }}><Icon.split/> {split?'Single':'Split'}</button>
          </div>

          {/* Scrub bar — Feature 2 */}
          <div style={{ padding: '14px 24px 6px', borderTop: '1px solid #ededed', background: '#fff' }}>
            <div ref={barRef} onMouseDown={startScrub} style={{ height: 30, position: 'relative', cursor: 'pointer', userSelect: 'none' }}>
              <div style={{ position: 'absolute', left: 0, right: 0, top: 0, display: 'flex', justifyContent: 'space-between', fontFamily: 'Geist Mono, monospace', fontSize: 9.5, color: '#a1a1aa' }}>
                <span>0.0s</span><span>{(totalDur*0.25).toFixed(1)}s</span><span>{(totalDur*0.5).toFixed(1)}s</span><span>{(totalDur*0.75).toFixed(1)}s</span><span>{totalDur.toFixed(1)}s</span>
              </div>
              <div style={{ position: 'absolute', left: 0, right: 0, top: 18, height: 5, background: 'rgba(15,23,42,0.08)', borderRadius: 99 }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${time*100}%`, background: 'linear-gradient(90deg,#7c3aed,#ec4899)', borderRadius: 99 }}/>
              </div>
              <div style={{ position: 'absolute', left: `calc(${time*100}% - 8px)`, top: 12, width: 16, height: 18, borderRadius: 4, background: '#fff', border: '2px solid #7c3aed', boxShadow: '0 4px 10px rgba(124,58,237,0.3)' }}/>
            </div>
          </div>

          {/* Play bar — Feature 9 + scrub time */}
          <div style={{ padding: '4px 22px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#fff' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <button onClick={() => { if (time >= 1) setTime(0); setPlaying(p => !p); setDirection(1); }} style={{ width: 32, height: 32, background: 'linear-gradient(135deg,#7c3aed,#ec4899)', border: 'none', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', cursor: 'pointer' }}>{playing ? <Icon.pause/> : <Icon.play/>}</button>
              <span style={{ color: '#71717a', fontFamily: 'Geist Mono, monospace', fontSize: 11.5 }}>{cur}s / {dur}s</span>
            </div>
            <div style={{ display: 'flex', padding: 3, background: '#f4f4f5', borderRadius: 8, gap: 2 }}>
              {[
                { id: 'once',     icon: Icon.once,     label: 'Once' },
                { id: 'loop',     icon: Icon.loop,     label: 'Loop' },
                { id: 'pingpong', icon: Icon.pingpong, label: 'Ping-pong' },
              ].map(m => { const ICN = m.icon; return (
                <button key={m.id} onClick={() => setLoopMode(m.id)} style={{ padding: '5px 10px', display: 'flex', alignItems: 'center', gap: 5, background: loopMode===m.id?'#fff':'transparent', border: 'none', borderRadius: 6, color: loopMode===m.id?'#0a0a14':'#71717a', fontWeight: 500, fontSize: 11, fontFamily: 'inherit', cursor: 'pointer', boxShadow: loopMode===m.id?'0 1px 2px rgba(0,0,0,0.06)':'none' }}><ICN/> {m.label}</button>
              ); })}
            </div>
            <button onClick={() => { setTime(0); setPlaying(true); setDirection(1); }} style={{ background: '#fff', border: '1px solid #ededed', color: '#3f3f46', padding: '6px 12px', borderRadius: 7, fontSize: 11.5, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}><Icon.replay/> Replay</button>
          </div>
        </main>
      </div>

      {showKbd && <KeyboardOverlay onClose={() => setShowKbd(false)}/>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
